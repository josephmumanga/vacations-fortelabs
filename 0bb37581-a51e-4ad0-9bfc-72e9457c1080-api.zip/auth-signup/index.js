const bcrypt = require('bcrypt');
const sql = require('mssql');
const { query, execute } = require('../lib/db');
const { generateToken, validateEmailDomain } = require('../lib/auth');

module.exports = async function (context, req) {
  context.log('Signup function processed a request.');

  try {
    const { email, password, name, role } = req.body;

    if (!email || !password) {
      context.res = {
        status: 400,
        body: { error: 'Email and password are required' }
      };
      return;
    }

    // Validate email domain
    if (!validateEmailDomain(email)) {
      context.res = {
        status: 403,
        body: { error: 'Only @forteinnovation.mx email addresses are allowed' }
      };
      return;
    }

    const emailLower = email.toLowerCase().trim();

    // Check if user already exists
    const existingUsers = await query(
      `SELECT id FROM users WHERE email = @email`,
      { email: { type: sql.NVarChar, value: emailLower } }
    );

    if (existingUsers.length > 0) {
      context.res = {
        status: 409,
        body: { error: 'User already exists. Please sign in instead.' }
      };
      return;
    }

    // Hash password
    const passwordHash = await bcrypt.hash(password, 10);

    // Determine role
    const userRole = emailLower === 'centro.id@forteinnovation.mx' ? 'Admin' : (role || 'Collaborator');
    const userName = name || emailLower.split('@')[0];

    // Create user and profile using SQL NEWID() for better compatibility
    const result = await query(
      `DECLARE @userId UNIQUEIDENTIFIER = NEWID();
       INSERT INTO users (id, email, password_hash) 
       VALUES (@userId, @email, @passwordHash);
       INSERT INTO profiles (id, name, role) 
       VALUES (@userId, @name, @role);
       SELECT @userId AS id;`,
      {
        email: { type: sql.NVarChar, value: emailLower },
        passwordHash: { type: sql.NVarChar, value: passwordHash },
        name: { type: sql.NVarChar, value: userName },
        role: { type: sql.NVarChar, value: userRole }
      }
    );

    const userId = result[0].id;

    // Generate token (convert userId to string)
    const token = await generateToken(userId.toString(), emailLower);

    // Get created profile
    const profiles = await query(
      `SELECT id, name, role, department, position, leader_name, join_date, balance, has_project, created_at, updated_at
       FROM profiles WHERE id = @userId`,
      { userId: { type: sql.UniqueIdentifier, value: userId } }
    );

    const profile = profiles[0];

    context.res = {
      status: 201,
      body: {
        user: {
          id: userId.toString(),
          email: emailLower
        },
        profile: {
          id: profile.id ? profile.id.toString() : userId.toString(),
          email: emailLower,
          name: profile.name,
          role: profile.role,
          department: profile.department,
          position: profile.position,
          leader_name: profile.leader_name,
          join_date: profile.join_date,
          balance: profile.balance || 0,
          has_project: profile.has_project || false,
          created_at: profile.created_at,
          updated_at: profile.updated_at
        },
        token
      }
    };
  } catch (error) {
    context.log.error('Signup error:', error);
    context.log.error('Error stack:', error.stack);
    context.log.error('Error details:', JSON.stringify(error, Object.getOwnPropertyNames(error)));
    
    // Always return error details in production for debugging
    const errorMessage = error.message || 'Internal server error';
    context.res = {
      status: 500,
      body: { 
        error: errorMessage,
        details: error.stack,
        code: error.code,
        number: error.number
      }
    };
  }
};

