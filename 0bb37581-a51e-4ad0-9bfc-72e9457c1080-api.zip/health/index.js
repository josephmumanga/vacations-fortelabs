module.exports = async function (context, req) {
  context.log('Health check function processed a request.');

  const envVars = {
    hasSqlServer: !!process.env.AZURE_SQL_SERVER,
    hasSqlDatabase: !!process.env.AZURE_SQL_DATABASE,
    hasSqlUser: !!process.env.AZURE_SQL_USER,
    hasSqlPassword: !!process.env.AZURE_SQL_PASSWORD,
    hasJwtSecret: !!process.env.JWT_SECRET,
    nodeVersion: process.version,
    functionsRuntime: process.env.FUNCTIONS_WORKER_RUNTIME
  };

  context.res = {
    status: 200,
    headers: {
      'Content-Type': 'application/json'
    },
    body: {
      status: 'ok',
      timestamp: new Date().toISOString(),
      environment: envVars
    }
  };
};


